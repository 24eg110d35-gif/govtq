import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useQueue } from '../../context/QueueContext';
import { DigitalToken } from '../../types/queue';
import { TokenGeneratorModal } from './TokenGeneratorModal';
import { TokenReceiptModal } from './TokenReceiptModal';
import { DocumentOcrModal } from './DocumentOcrModal';
import { OcrExtractedData } from '../../services/picnie';
import { QueueApi } from '../../services/api';
import {
  Ticket,
  Clock,
  Users,
  CheckCircle2,
  AlertTriangle,
  Printer,
  FileSearch,
  Building2,
  Calendar,
  Sparkles,
  Coffee,
  XCircle,
  HelpCircle,
} from 'lucide-react';

export const CitizenDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const {
    tokens,
    offices,
    counters,
    setActiveReceiptToken,
    activeReceiptToken,
    showOcrModal,
    setShowOcrModal,
    showNewTokenModal,
    setShowNewTokenModal,
  } = useQueue();

  const [prefilledOcr, setPrefilledOcr] = useState<OcrExtractedData | null>(null);

  // Filter tokens belonging to this logged in citizen
  const citizenTokens = tokens.filter((t) => t.citizenId === currentUser?.id);
  const activeToken = citizenTokens.find((t) => t.status === 'WAITING' || t.status === 'SERVING');
  const pastTokens = citizenTokens.filter((t) => t.status === 'COMPLETED' || t.status === 'SKIPPED');

  // Currently serving token for the same service
  let currentlyServingSameService: DigitalToken | undefined;
  let peopleAhead = 0;
  let activeDesksCount = 0;
  let breakDesksCount = 0;

  if (activeToken) {
    currentlyServingSameService = tokens.find(
      (t) => t.serviceId === activeToken.serviceId && t.status === 'SERVING'
    );
    peopleAhead = tokens.filter(
      (t) =>
        t.serviceId === activeToken.serviceId &&
        t.status === 'WAITING' &&
        new Date(t.createdAt).getTime() < new Date(activeToken.createdAt).getTime()
    ).length;

    const serviceCounters = counters.filter((c) => c.serviceIds.includes(activeToken.serviceId));
    activeDesksCount = serviceCounters.filter((c) => c.status === 'active').length;
    breakDesksCount = serviceCounters.filter((c) => c.status === 'break').length;
  }

  const handleApplyOcr = (ocrData: OcrExtractedData) => {
    setPrefilledOcr(ocrData);
    setShowNewTokenModal(true);
  };

  return (
    <div className="space-y-8">
      {/* Citizen Welcome Card */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 text-white shadow-2xl">
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/smartgov_hero_civic_1791864625216.jpg"
            alt="Civic Service Center"
            className="w-full h-full object-cover opacity-20"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-transparent" />
        </div>

        <div className="relative z-10 p-6 sm:p-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Authenticated Citizen Portal · {currentUser?.name}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-2 text-balance">
            Digital Token & Queue Management
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed mb-6">
            Generate digital service tokens, track real-time queue sequences, and view dynamic wait estimations calculated by active service desks.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                setPrefilledOcr(null);
                setShowNewTokenModal(true);
              }}
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 shadow-lg shadow-cyan-500/25 cursor-pointer"
            >
              <Ticket className="w-4 h-4" />
              <span>Get Digital Token</span>
            </button>

            <button
              onClick={() => setShowOcrModal(true)}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold text-xs tracking-wide transition-colors flex items-center gap-2 cursor-pointer backdrop-blur-xs"
            >
              <FileSearch className="w-4 h-4 text-cyan-400" />
              <span>Scan Supporting Document (OCR)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Active Token Tracker Spotlight */}
      {activeToken ? (
        <div
          className={`rounded-2xl border p-6 sm:p-8 transition-all shadow-xl ${
            activeToken.status === 'SERVING'
              ? 'bg-cyan-950/20 border-cyan-500 ring-2 ring-cyan-500/30'
              : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider mb-1">
                <span className={activeToken.status === 'SERVING' ? 'text-cyan-400 font-extrabold' : 'text-slate-400'}>
                  Active Token Tracker
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400 font-mono">
                  Issued {new Date(activeToken.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">
                {activeToken.serviceName}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>{activeToken.officeName}</span>
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="bg-slate-950 border border-slate-800 text-white px-6 py-4 rounded-xl text-center shadow-lg">
                <span className="text-[10px] text-cyan-400 uppercase tracking-widest font-bold block">
                  Your Token
                </span>
                <span className="text-3xl sm:text-4xl font-black font-mono tracking-tight block tabular-nums text-cyan-300">
                  {activeToken.tokenNumber}
                </span>
              </div>
              <button
                onClick={() => setActiveReceiptToken(activeToken)}
                className="px-4 py-3 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-cyan-400" />
                <span>View Receipt</span>
              </button>
            </div>
          </div>

          {/* Real-Time Callout */}
          {activeToken.status === 'SERVING' ? (
            <div className="my-6 p-5 rounded-xl bg-cyan-500 text-slate-950 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-950 text-cyan-400 flex items-center justify-center font-bold text-lg shrink-0">
                  !
                </div>
                <div>
                  <h3 className="font-extrabold text-base leading-tight">
                    PROCEED TO COUNTER {activeToken.counterNumber || 1} IMMEDIATELY!
                  </h3>
                  <p className="text-xs text-slate-900 mt-0.5">
                    Officer {activeToken.staffName || 'Staff Officer'} is calling your token right now.
                    Please approach with your verification documents.
                  </p>
                </div>
              </div>
              <span className="px-3.5 py-1.5 rounded-lg bg-slate-950 text-cyan-300 font-mono text-xs font-bold shrink-0">
                ACTIVE AT DESK
              </span>
            </div>
          ) : (
            <div className="my-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Stat 1: Serving Token */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-xs text-slate-400 block mb-1">Currently Serving</span>
                <div className="text-2xl font-bold font-mono text-white tabular-nums">
                  {currentlyServingSameService ? currentlyServingSameService.tokenNumber : 'None (Idle)'}
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  {currentlyServingSameService?.counterNumber
                    ? `At Counter ${currentlyServingSameService.counterNumber}`
                    : 'Awaiting next queue call'}
                </span>
              </div>

              {/* Stat 2: People Ahead */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-xs text-slate-400 block mb-1">People Ahead in Line</span>
                <div className="text-2xl font-bold font-mono text-white tabular-nums flex items-baseline gap-1.5">
                  <span>{peopleAhead}</span>
                  <span className="text-xs font-normal text-slate-400">citizens</span>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  {peopleAhead === 0 ? 'You are next in turn!' : 'Sequential order'}
                </span>
              </div>

              {/* Stat 3: Estimated Wait Time with Active Desk Context */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slate-400">Estimated Wait Time</span>
                  {breakDesksCount > 0 && (
                    <span className="text-[10px] text-amber-400 font-semibold flex items-center gap-1">
                      <Coffee className="w-3 h-3" />
                      <span>{breakDesksCount} on break</span>
                    </span>
                  )}
                </div>
                <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums flex items-baseline gap-1.5">
                  <span>~{activeToken.estimatedWaitMinutes}</span>
                  <span className="text-xs font-normal text-slate-400">minutes</span>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Calculated across {activeDesksCount || 1} currently active open desk(s)
                </span>
              </div>
            </div>
          )}

          {/* Stepper Progress */}
          <div className="pt-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-3">
              Queue Life-Cycle Progress
            </span>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="space-y-1">
                <div className="h-2 rounded-full bg-cyan-500" />
                <span className="font-semibold text-white block text-[11px]">1. Token Issued</span>
              </div>
              <div className="space-y-1">
                <div
                  className={`h-2 rounded-full ${
                    activeToken.status === 'WAITING' || activeToken.status === 'SERVING'
                      ? 'bg-cyan-500'
                      : 'bg-slate-800'
                  }`}
                />
                <span className={`block text-[11px] ${activeToken.status === 'WAITING' ? 'font-bold text-cyan-400' : 'text-slate-400'}`}>
                  2. Waiting in Line
                </span>
              </div>
              <div className="space-y-1">
                <div
                  className={`h-2 rounded-full ${
                    activeToken.status === 'SERVING' ? 'bg-cyan-500 animate-pulse' : 'bg-slate-800'
                  }`}
                />
                <span className={`block text-[11px] ${activeToken.status === 'SERVING' ? 'font-bold text-cyan-400' : 'text-slate-400'}`}>
                  3. Called to Desk
                </span>
              </div>
              <div className="space-y-1">
                <div className="h-2 rounded-full bg-slate-800" />
                <span className="text-slate-500 block text-[11px]">4. Completed</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/60 p-8 sm:p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto mb-4">
            <Ticket className="w-7 h-7" />
          </div>
          <h2 className="text-lg font-bold text-white mb-1">
            No Active Queue Token Allocated
          </h2>
          <p className="text-xs text-slate-400 max-w-md mx-auto mb-6">
            You do not currently have a token waiting in the queue. Select a government department and service below to obtain your digital pass.
          </p>
          <button
            onClick={() => {
              setPrefilledOcr(null);
              setShowNewTokenModal(true);
            }}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/20"
          >
            <Ticket className="w-4 h-4" />
            <span>Generate New Token Now</span>
          </button>
        </div>
      )}

      {/* Citizen Past Visits */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-md">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wide">
              Your Queue History & Completed Services
            </h3>
            <p className="text-xs text-slate-400">Historical records of your public administration visits</p>
          </div>
          <span className="text-xs text-slate-400 font-mono tabular-nums">
            {pastTokens.length} completed visit(s)
          </span>
        </div>

        {pastTokens.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No previous token history on record for this citizen account.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="text-[11px] uppercase tracking-wider text-slate-400 bg-slate-950 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Token</th>
                  <th className="py-2.5 px-3 font-semibold">Service</th>
                  <th className="py-2.5 px-3 font-semibold">Office</th>
                  <th className="py-2.5 px-3 font-semibold">Date & Time</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Pass</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {pastTokens.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-cyan-300 tabular-nums">
                      {t.tokenNumber}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-200">{t.serviceName}</td>
                    <td className="py-3 px-3 text-slate-400 truncate max-w-[200px]">{t.officeName}</td>
                    <td className="py-3 px-3 text-slate-400 font-mono tabular-nums">
                      {new Date(t.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`text-[11px] font-bold uppercase ${t.status === 'COMPLETED' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {t.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setActiveReceiptToken(t)}
                        className="px-2.5 py-1 text-[11px] font-semibold rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 transition-colors cursor-pointer"
                      >
                        Receipt
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <TokenGeneratorModal
        isOpen={showNewTokenModal}
        onClose={() => setShowNewTokenModal(false)}
        prefilledOcrData={prefilledOcr}
      />
      <DocumentOcrModal
        isOpen={showOcrModal}
        onClose={() => setShowOcrModal(false)}
        onApplyExtractedData={handleApplyOcr}
      />
      <TokenReceiptModal
        token={activeReceiptToken}
        onClose={() => setActiveReceiptToken(null)}
      />
    </div>
  );
};
