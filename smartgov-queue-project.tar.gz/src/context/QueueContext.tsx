import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  DigitalToken,
  GovernmentOffice,
  GovernmentService,
  InAppNotification,
  QueueEvent,
  QueueStatistics,
  ServiceCounter,
} from '../types/queue';
import { QueueApi } from '../services/api';
import { useAuth } from './AuthContext';
import { playQueueChime } from '../utils/audioChime';

interface QueueContextType {
  offices: GovernmentOffice[];
  services: GovernmentService[];
  counters: ServiceCounter[];
  tokens: DigitalToken[];
  events: QueueEvent[];
  notifications: InAppNotification[];
  stats: QueueStatistics | null;
  loading: boolean;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  refreshData: () => Promise<void>;

  // Token operations
  generateToken: (params: {
    officeId: string;
    serviceId: string;
    priority?: 'STANDARD' | 'SENIOR_CITIZEN' | 'SPECIALLY_ABLED';
    notes?: string;
    ocrProcessed?: boolean;
  }) => Promise<DigitalToken>;
  callNext: (counterId: string) => Promise<{ token: DigitalToken; message: string }>;
  callSpecific: (tokenId: string, counterId: string) => Promise<DigitalToken>;
  completeService: (tokenId: string, counterId: string, notes?: string) => Promise<DigitalToken>;
  skipToken: (tokenId: string, counterId: string, reason: string) => Promise<DigitalToken>;
  updateCounterStatus: (counterId: string, status: 'active' | 'break' | 'closed') => Promise<void>;
  markNotificationRead: (notifId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  resetToDemoState: () => void;

  // Active Modals & Overlays
  activeReceiptToken: DigitalToken | null;
  setActiveReceiptToken: (token: DigitalToken | null) => void;
  showOcrModal: boolean;
  setShowOcrModal: (show: boolean) => void;
  showArchitectureModal: boolean;
  setShowArchitectureModal: (show: boolean) => void;
  showTestSuiteModal: boolean;
  setShowTestSuiteModal: (show: boolean) => void;
  showNewTokenModal: boolean;
  setShowNewTokenModal: (show: boolean) => void;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [offices, setOffices] = useState<GovernmentOffice[]>([]);
  const [services, setServices] = useState<GovernmentService[]>([]);
  const [counters, setCounters] = useState<ServiceCounter[]>([]);
  const [tokens, setTokens] = useState<DigitalToken[]>([]);
  const [events, setEvents] = useState<QueueEvent[]>([]);
  const [notifications, setNotifications] = useState<InAppNotification[]>([]);
  const [stats, setStats] = useState<QueueStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Modals
  const [activeReceiptToken, setActiveReceiptToken] = useState<DigitalToken | null>(null);
  const [showOcrModal, setShowOcrModal] = useState(false);
  const [showArchitectureModal, setShowArchitectureModal] = useState(false);
  const [showTestSuiteModal, setShowTestSuiteModal] = useState(false);
  const [showNewTokenModal, setShowNewTokenModal] = useState(false);

  // Track previous tokens for user to trigger audio chime when called
  const prevTokensRef = useRef<DigitalToken[]>([]);

  const refreshData = useCallback(async () => {
    try {
      const [allOffices, allServices, allCounters, allTokens, allEvents, allStats] = await Promise.all([
        QueueApi.getOffices(),
        QueueApi.getServices(),
        QueueApi.getCounters(),
        QueueApi.getTokens(),
        QueueApi.getEvents(),
        QueueApi.getStatistics(),
      ]);

      setOffices(allOffices);
      setServices(allServices);
      setCounters(allCounters);
      setTokens(allTokens);
      setEvents(allEvents);
      setStats(allStats);

      if (currentUser?.id) {
        const userNotifs = await QueueApi.getNotifications(currentUser.id);
        setNotifications(userNotifs);

        // Check if any token for the current user just changed to SERVING
        if (prevTokensRef.current.length > 0 && soundEnabled) {
          const userServingToken = allTokens.find(
            (t) => t.citizenId === currentUser.id && t.status === 'SERVING'
          );
          const wasAlreadyServing = prevTokensRef.current.some(
            (pt) => pt.id === userServingToken?.id && pt.status === 'SERVING'
          );

          if (userServingToken && !wasAlreadyServing) {
            playQueueChime('called');
          }
        }
      }

      prevTokensRef.current = allTokens;
    } catch (err) {
      console.error('Error refreshing queue state:', err);
    } finally {
      setLoading(false);
    }
  }, [currentUser?.id, soundEnabled]);

  // Initial load and periodic polling
  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 3000);

    const handleStorageUpdate = () => {
      refreshData();
    };

    window.addEventListener('smartgov_storage_update', handleStorageUpdate);
    window.addEventListener('storage', handleStorageUpdate);

    return () => {
      clearInterval(interval);
      window.removeEventListener('smartgov_storage_update', handleStorageUpdate);
      window.removeEventListener('storage', handleStorageUpdate);
    };
  }, [refreshData]);

  const generateToken = async (params: {
    officeId: string;
    serviceId: string;
    priority?: 'STANDARD' | 'SENIOR_CITIZEN' | 'SPECIALLY_ABLED';
    notes?: string;
    ocrProcessed?: boolean;
  }): Promise<DigitalToken> => {
    if (!currentUser) throw new Error('Citizen must be logged in to generate a token.');
    const token = await QueueApi.generateToken({
      ...params,
      citizenId: currentUser.id,
      citizenName: currentUser.name,
      citizenPhone: currentUser.phone || '+91 98765 00000',
      citizenNationalId: currentUser.nationalId || 'CID-DEMO-001',
    });
    if (soundEnabled) {
      playQueueChime('generated');
    }
    await refreshData();
    return token;
  };

  const callNext = async (counterId: string) => {
    if (!currentUser) throw new Error('Staff credentials required.');
    const result = await QueueApi.callNextToken({
      counterId,
      staffId: currentUser.staffId || currentUser.id,
      staffName: currentUser.name,
    });
    if (soundEnabled) {
      playQueueChime('called');
    }
    await refreshData();
    return result;
  };

  const callSpecific = async (tokenId: string, counterId: string) => {
    if (!currentUser) throw new Error('Staff credentials required.');
    const result = await QueueApi.callSpecificToken({
      tokenId,
      counterId,
      staffId: currentUser.staffId || currentUser.id,
      staffName: currentUser.name,
    });
    if (soundEnabled) {
      playQueueChime('called');
    }
    await refreshData();
    return result;
  };

  const completeService = async (tokenId: string, counterId: string, notes?: string) => {
    if (!currentUser) throw new Error('Staff credentials required.');
    const result = await QueueApi.completeService({
      tokenId,
      counterId,
      staffName: currentUser.name,
      serviceNotes: notes,
    });
    if (soundEnabled) {
      playQueueChime('completed');
    }
    await refreshData();
    return result;
  };

  const skipToken = async (tokenId: string, counterId: string, reason: string) => {
    if (!currentUser) throw new Error('Staff credentials required.');
    const result = await QueueApi.skipToken({
      tokenId,
      counterId,
      staffName: currentUser.name,
      reason,
    });
    await refreshData();
    return result;
  };

  const updateCounterStatus = async (counterId: string, status: 'active' | 'break' | 'closed') => {
    await QueueApi.updateCounterStatus(counterId, status);
    await refreshData();
  };

  const markNotificationRead = async (notifId: string) => {
    await QueueApi.markNotificationRead(notifId);
    if (currentUser?.id) {
      const updated = await QueueApi.getNotifications(currentUser.id);
      setNotifications(updated);
    }
  };

  const markAllNotificationsRead = async () => {
    if (!currentUser?.id) return;
    await QueueApi.markAllNotificationsRead(currentUser.id);
    const updated = await QueueApi.getNotifications(currentUser.id);
    setNotifications(updated);
  };

  const resetToDemoState = () => {
    QueueApi.resetDemoData();
    refreshData();
  };

  return (
    <QueueContext.Provider
      value={{
        offices,
        services,
        counters,
        tokens,
        events,
        notifications,
        stats,
        loading,
        soundEnabled,
        setSoundEnabled,
        refreshData,
        generateToken,
        callNext,
        callSpecific,
        completeService,
        skipToken,
        updateCounterStatus,
        markNotificationRead,
        markAllNotificationsRead,
        resetToDemoState,
        activeReceiptToken,
        setActiveReceiptToken,
        showOcrModal,
        setShowOcrModal,
        showArchitectureModal,
        setShowArchitectureModal,
        showTestSuiteModal,
        setShowTestSuiteModal,
        showNewTokenModal,
        setShowNewTokenModal,
      }}
    >
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = (): QueueContextType => {
  const context = useContext(QueueContext);
  if (!context) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
};
